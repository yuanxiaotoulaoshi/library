package com.ischoolbar.programmer.dao;

import com.ischoolbar.programmer.entity.User;

public class UserDao extends BaseDao<User> {
}
