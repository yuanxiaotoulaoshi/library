package com.ischoolbar.programmer.dao;

import com.ischoolbar.programmer.entity.BookCategory;

public class BookCategoryDao extends BaseDao<BookCategory> {

}
