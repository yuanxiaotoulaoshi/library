package com.ischoolbar.programmer.dao;

import com.ischoolbar.programmer.entity.Book;

public class BookDao extends BaseDao<Book> {

}
